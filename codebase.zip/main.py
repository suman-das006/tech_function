def hello_world(request):
    """Responds with 'Hello, World!' when triggered."""
    return "Hello, World!", 200
